import java.util.Scanner;

public class Write_Mulitplication_Table {
    public static void main(String[] args) {
        int num;
        int mNum = 0;
        int fNum; //Final Result Variable
        Scanner sn = new Scanner(System.in);

        System.out.println("Please Enter Any Number :");
        num = sn.nextInt(); //Get Input from the User...

        for (int i = 0; i<10; i++){
            if (mNum < 10){
                mNum++;
                fNum = num*mNum;
                System.out.println(fNum);
            }
        }
    }
}
